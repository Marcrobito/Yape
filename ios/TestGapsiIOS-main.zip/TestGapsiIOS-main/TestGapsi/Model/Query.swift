//
//  Query.swift
//  TestGapsi
//
//  Created by Marco Antonio Martínez Gutiérrez on 20/02/21.
//

import Foundation
import RealmSwift

class Query: Object {
    @objc dynamic var query = ""
}
